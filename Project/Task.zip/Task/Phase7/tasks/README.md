# Phase7 Tasks

## 索引

- [task-p7-00-workspace.md](task-p7-00-workspace.md)

## 使用方式

任务文件只回答三件事：
1. 怎么做。
2. 做到什么程度算完成。
3. 先做谁、后做谁。

架构约束请先看 `architecture/`。
