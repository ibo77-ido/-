# Phase7 Architecture

## 索引

- [P7-00_PHASE_OVERVIEW.md](P7-00_PHASE_OVERVIEW.md)

## 使用方式

Phase7 架构文件只回答三件事：
1. 这阶段要做什么。
2. 这阶段不做什么。
3. 完成标准是什么。

实现细节交给 `tasks/`。
