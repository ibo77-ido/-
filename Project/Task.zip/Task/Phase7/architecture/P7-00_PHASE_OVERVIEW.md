# P7-00 Phase Overview

## Phase7 目标

Phase7 的目标是把 Phase3 的核心玩法，正式接入 Phase6 的 2.5D 白盒空间，形成可连续运行的垂直切片。

本阶段优先级：
1. 玩法闭环
2. 状态切换
3. 工作台接入
4. 区域与交互稳定

## Phase7 边界

必须保留：
- `LogicRoot / ArtRoot`
- `Phase6GameManager`
- `AreaTrigger`
- `Workstation + InteractionPoint`
- `ScaleManager`
- 白盒测试 UI 作为过渡层

本阶段不做：
- 正式美术替换
- 大规模重构 Phase3 算法
- 新增复杂经济系统
- 新增正式烧制缺陷体系

## 完成定义

Phase7 允许进入下一阶段的条件：
- 订单到结果的主链路可连续完成
- 移动、交互、UI 打开/关闭稳定
- 区域切换不抖动
- Play Mode 无阻断性报错
- 连续 3 轮流程可复现

## 开发顺序

1. 场景与引用绑定
2. 交互与移动闸门收口
3. 工作台到玩法面板接通
4. 完整流程闭环
5. 区域与工作台稳定性
6. 验证与收口
